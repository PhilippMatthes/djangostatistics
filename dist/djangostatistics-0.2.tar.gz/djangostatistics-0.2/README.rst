djangostatistics is a simple Django app for keeping track of interactions and display them in a generic statistics admin view.

Quick start
-----------

Please read the instructions under https://github.com/PhilippMatthes/djangostatistics.
